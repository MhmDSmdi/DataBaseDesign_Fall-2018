SELECT title, (max(stars) - min(stars)) AS "rating spread"
FROM Movie NATURAL JOIN Rating
GROUP BY title
ORDER BY "rating spread" DESC, title ASC
