SELECT Reviewer.name, Movie.title, Rating.stars, Rating.ratingDate
FROM Movie, Rating, Reviewer
WHERE Rating.mID = Movie.mID AND Rating.rID = Reviewer.rID
ORDER BY Reviewer.name, Movie.title, Rating.stars;