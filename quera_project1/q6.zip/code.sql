SELECT name, title
FROM Movie INNER JOIN Rating movieJoin USING(mID) INNER JOIN Rating rmJoin USING(rID, mID) INNER JOIN Reviewer USING(rID)
WHERE movieJoin.ratingDate < rmJoin.ratingDate AND movieJoin.stars < rmJoin.stars