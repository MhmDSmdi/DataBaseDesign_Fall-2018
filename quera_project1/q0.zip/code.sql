Select *
From Movie