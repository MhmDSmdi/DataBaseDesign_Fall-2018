select title, max(stars)
from Movie natural join Rating
group by title
order by title
