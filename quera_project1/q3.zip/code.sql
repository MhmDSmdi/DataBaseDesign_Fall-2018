SELECT Movie.title
FROM Movie LEFT JOIN Rating ON Movie.mID = Rating.mID
WHERE Rating.mID IS NULL;
