SELECT Reviewer.name
FROM Reviewer LEFT JOIN Rating ON Reviewer.rID = Rating.rID
WHERE Rating.ratingDate IS NULL;
