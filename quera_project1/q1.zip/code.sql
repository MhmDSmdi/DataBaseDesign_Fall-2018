SELECT title
FROM Movie
WHERE director = "Steven Spielberg";