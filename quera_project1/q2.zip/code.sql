SELECT mID
FROM Movie
WHERE Movie.year IN (SELECT Movie.year
                    FROM Movie, Rating
                    WHERE Movie.mID = Rating.mID AND (Rating.stars = 4 OR Rating.stars = 5))
ORDER BY mID ASC;